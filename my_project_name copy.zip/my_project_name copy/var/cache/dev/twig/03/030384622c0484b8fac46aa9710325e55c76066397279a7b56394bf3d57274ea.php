<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_f6b97e1fdec0e36a1f8d37680cec7aa573fe3863d309f6c48ebdc5696deb3fe7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b36f25b94f4cb0eb235e40bad750891d7b1a5128b3bf6f0a926c336e3bc71e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b36f25b94f4cb0eb235e40bad750891d7b1a5128b3bf6f0a926c336e3bc71e7->enter($__internal_1b36f25b94f4cb0eb235e40bad750891d7b1a5128b3bf6f0a926c336e3bc71e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_1b36f25b94f4cb0eb235e40bad750891d7b1a5128b3bf6f0a926c336e3bc71e7->leave($__internal_1b36f25b94f4cb0eb235e40bad750891d7b1a5128b3bf6f0a926c336e3bc71e7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
    }
}
