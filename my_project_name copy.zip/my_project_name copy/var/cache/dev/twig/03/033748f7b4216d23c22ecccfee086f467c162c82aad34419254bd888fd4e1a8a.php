<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_1010c0a3494fcad84af5fefbfc60da0fbbd031441b6b43536769da6a7d225800 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b36596a428c9c7e19b741bb3884e924b3599478daf95aee9838e2c91cd48c3f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b36596a428c9c7e19b741bb3884e924b3599478daf95aee9838e2c91cd48c3f6->enter($__internal_b36596a428c9c7e19b741bb3884e924b3599478daf95aee9838e2c91cd48c3f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_b36596a428c9c7e19b741bb3884e924b3599478daf95aee9838e2c91cd48c3f6->leave($__internal_b36596a428c9c7e19b741bb3884e924b3599478daf95aee9838e2c91cd48c3f6_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/error.xml.twig' %}
";
    }
}
