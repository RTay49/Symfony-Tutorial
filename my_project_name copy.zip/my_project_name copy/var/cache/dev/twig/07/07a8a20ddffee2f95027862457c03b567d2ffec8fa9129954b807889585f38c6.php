<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_386a5adae8754803fbfbc6c1767b08a93df07d46e77c8c498dd5545c79f024ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_360dfaff616b66801fd73d3b04d413608775bf67f2239ba35e187e26a637f54f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_360dfaff616b66801fd73d3b04d413608775bf67f2239ba35e187e26a637f54f->enter($__internal_360dfaff616b66801fd73d3b04d413608775bf67f2239ba35e187e26a637f54f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_360dfaff616b66801fd73d3b04d413608775bf67f2239ba35e187e26a637f54f->leave($__internal_360dfaff616b66801fd73d3b04d413608775bf67f2239ba35e187e26a637f54f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
    }
}
