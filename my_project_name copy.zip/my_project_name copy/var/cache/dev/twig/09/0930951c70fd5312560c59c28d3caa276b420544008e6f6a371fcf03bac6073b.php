<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_179b3af5f2772801ba4ee983468eae46d60bc1458b8c3640c32908bc3abe8a0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b7d3b05fc1e525efd8fd1a2c3de83b4dacbb9e3c61d4becae669049b5afe5fb9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7d3b05fc1e525efd8fd1a2c3de83b4dacbb9e3c61d4becae669049b5afe5fb9->enter($__internal_b7d3b05fc1e525efd8fd1a2c3de83b4dacbb9e3c61d4becae669049b5afe5fb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_b7d3b05fc1e525efd8fd1a2c3de83b4dacbb9e3c61d4becae669049b5afe5fb9->leave($__internal_b7d3b05fc1e525efd8fd1a2c3de83b4dacbb9e3c61d4becae669049b5afe5fb9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
    }
}
