<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_62b95ac1eb313676747832b0d6ee684c1197add91be409ac50a13a6f27ae9e73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d0ba4a68d86b8401794658b4066c2150c4298e85bc677dc58dbc9768e373b3ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0ba4a68d86b8401794658b4066c2150c4298e85bc677dc58dbc9768e373b3ce->enter($__internal_d0ba4a68d86b8401794658b4066c2150c4298e85bc677dc58dbc9768e373b3ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_d0ba4a68d86b8401794658b4066c2150c4298e85bc677dc58dbc9768e373b3ce->leave($__internal_d0ba4a68d86b8401794658b4066c2150c4298e85bc677dc58dbc9768e373b3ce_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }

    public function getSource()
    {
        return "/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
";
    }
}
