<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_4a1c51d714ce3963fc4ea712df005b76a3bdd7d7d2b6c4ee2badc55639190a7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5cbd0a308a00e6f151fe446115e32d748731d559be9ed2d2b52d97ef1925b469 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cbd0a308a00e6f151fe446115e32d748731d559be9ed2d2b52d97ef1925b469->enter($__internal_5cbd0a308a00e6f151fe446115e32d748731d559be9ed2d2b52d97ef1925b469_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_5cbd0a308a00e6f151fe446115e32d748731d559be9ed2d2b52d97ef1925b469->leave($__internal_5cbd0a308a00e6f151fe446115e32d748731d559be9ed2d2b52d97ef1925b469_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
    }
}
