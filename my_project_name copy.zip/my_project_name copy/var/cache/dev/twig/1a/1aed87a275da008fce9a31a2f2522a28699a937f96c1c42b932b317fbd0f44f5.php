<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_a4ed8677258ac2fa9138adee1758eb1386491ca32eb20b2951c487abb64897a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2282c28edb5f0a5ca0e17bfafe2fe688b1ca86896ccf1c3fb9afb928d5b9c67e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2282c28edb5f0a5ca0e17bfafe2fe688b1ca86896ccf1c3fb9afb928d5b9c67e->enter($__internal_2282c28edb5f0a5ca0e17bfafe2fe688b1ca86896ccf1c3fb9afb928d5b9c67e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_2282c28edb5f0a5ca0e17bfafe2fe688b1ca86896ccf1c3fb9afb928d5b9c67e->leave($__internal_2282c28edb5f0a5ca0e17bfafe2fe688b1ca86896ccf1c3fb9afb928d5b9c67e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
";
    }
}
