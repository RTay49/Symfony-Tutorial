<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_49931cf850eaa696851f974195647cb7dad3195515997cd2bcaef009b05418cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89e7c4dbe00550de292bb2a54067229c0a6f63a25bd6d59cbe093e1ad1fc4375 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89e7c4dbe00550de292bb2a54067229c0a6f63a25bd6d59cbe093e1ad1fc4375->enter($__internal_89e7c4dbe00550de292bb2a54067229c0a6f63a25bd6d59cbe093e1ad1fc4375_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_89e7c4dbe00550de292bb2a54067229c0a6f63a25bd6d59cbe093e1ad1fc4375->leave($__internal_89e7c4dbe00550de292bb2a54067229c0a6f63a25bd6d59cbe093e1ad1fc4375_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
    }
}
