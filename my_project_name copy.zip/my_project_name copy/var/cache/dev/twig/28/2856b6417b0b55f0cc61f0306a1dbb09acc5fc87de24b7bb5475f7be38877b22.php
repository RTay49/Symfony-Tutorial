<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_360b55eb70d93ef74808126089c50dd5581c48dd35ba3fee9e3aa50bbd6dff15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a9c4429f267a57777d14839dec130ed1f839d3dbe96e393d7a5219e36dfe745c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9c4429f267a57777d14839dec130ed1f839d3dbe96e393d7a5219e36dfe745c->enter($__internal_a9c4429f267a57777d14839dec130ed1f839d3dbe96e393d7a5219e36dfe745c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_a9c4429f267a57777d14839dec130ed1f839d3dbe96e393d7a5219e36dfe745c->leave($__internal_a9c4429f267a57777d14839dec130ed1f839d3dbe96e393d7a5219e36dfe745c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
    }
}
