<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_9cbbffd38ec2b5135b6ef3f503b6dbfcb6ac3403ec59878454945e608fbf4718 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_879028a0ebc18f4f2474607bd2470194258243bc9bbdbc0bca0d71aa675f3f05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_879028a0ebc18f4f2474607bd2470194258243bc9bbdbc0bca0d71aa675f3f05->enter($__internal_879028a0ebc18f4f2474607bd2470194258243bc9bbdbc0bca0d71aa675f3f05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_879028a0ebc18f4f2474607bd2470194258243bc9bbdbc0bca0d71aa675f3f05->leave($__internal_879028a0ebc18f4f2474607bd2470194258243bc9bbdbc0bca0d71aa675f3f05_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
    }
}
