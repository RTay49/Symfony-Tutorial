<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_b29004e685b7b673faf05adcb21bd0318585ca3a68309fcadc1882b9c5b92c4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_27f8a0a839939b96a115a113d24f367c36585199fd9db8e925abf9a44b0c5adc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27f8a0a839939b96a115a113d24f367c36585199fd9db8e925abf9a44b0c5adc->enter($__internal_27f8a0a839939b96a115a113d24f367c36585199fd9db8e925abf9a44b0c5adc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_27f8a0a839939b96a115a113d24f367c36585199fd9db8e925abf9a44b0c5adc->leave($__internal_27f8a0a839939b96a115a113d24f367c36585199fd9db8e925abf9a44b0c5adc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
    }
}
