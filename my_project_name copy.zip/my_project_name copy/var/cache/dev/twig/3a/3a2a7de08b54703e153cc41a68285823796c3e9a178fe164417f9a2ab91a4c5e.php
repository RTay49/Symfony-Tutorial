<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_ad4e5f6587e979bdff95e3aca8b1c60238b3776520818700254bf6aeacf4cd22 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_044aec809a8e4f1ad000507ea2768c2e5a4042b6c6e3da8e10b5b6e85359fd58 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_044aec809a8e4f1ad000507ea2768c2e5a4042b6c6e3da8e10b5b6e85359fd58->enter($__internal_044aec809a8e4f1ad000507ea2768c2e5a4042b6c6e3da8e10b5b6e85359fd58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_044aec809a8e4f1ad000507ea2768c2e5a4042b6c6e3da8e10b5b6e85359fd58->leave($__internal_044aec809a8e4f1ad000507ea2768c2e5a4042b6c6e3da8e10b5b6e85359fd58_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
    }
}
