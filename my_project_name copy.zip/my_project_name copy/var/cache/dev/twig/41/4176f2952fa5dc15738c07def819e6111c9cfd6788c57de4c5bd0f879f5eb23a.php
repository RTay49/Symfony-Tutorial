<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_d935f0dd2f2531aa6befeed762d00136e5dcd4cca49c7fe84592eaa6e8880983 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2cbb1c55590060d89ccba2f69b6d9d5d819555ca905dc902bd2f54dc6293d942 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2cbb1c55590060d89ccba2f69b6d9d5d819555ca905dc902bd2f54dc6293d942->enter($__internal_2cbb1c55590060d89ccba2f69b6d9d5d819555ca905dc902bd2f54dc6293d942_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_2cbb1c55590060d89ccba2f69b6d9d5d819555ca905dc902bd2f54dc6293d942->leave($__internal_2cbb1c55590060d89ccba2f69b6d9d5d819555ca905dc902bd2f54dc6293d942_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
    }
}
