<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_c65ea6f7daa404b82b078333fc03439e19580cb47af461fdebf6b818e905d23f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a276c0af7ef2cef63111365a8f970269913aca6089719aa63fcfdca731534afe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a276c0af7ef2cef63111365a8f970269913aca6089719aa63fcfdca731534afe->enter($__internal_a276c0af7ef2cef63111365a8f970269913aca6089719aa63fcfdca731534afe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_a276c0af7ef2cef63111365a8f970269913aca6089719aa63fcfdca731534afe->leave($__internal_a276c0af7ef2cef63111365a8f970269913aca6089719aa63fcfdca731534afe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
    }
}
