<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_40357dad888205c824f28433e31ef9ba7034778635263ccce47d870610c92ef0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82d3d7aa9d47130d7c2621c5e15e7ef42e85e7172ee45230c0cfcb4f3a2bb8a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82d3d7aa9d47130d7c2621c5e15e7ef42e85e7172ee45230c0cfcb4f3a2bb8a9->enter($__internal_82d3d7aa9d47130d7c2621c5e15e7ef42e85e7172ee45230c0cfcb4f3a2bb8a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_82d3d7aa9d47130d7c2621c5e15e7ef42e85e7172ee45230c0cfcb4f3a2bb8a9->leave($__internal_82d3d7aa9d47130d7c2621c5e15e7ef42e85e7172ee45230c0cfcb4f3a2bb8a9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
    }
}
