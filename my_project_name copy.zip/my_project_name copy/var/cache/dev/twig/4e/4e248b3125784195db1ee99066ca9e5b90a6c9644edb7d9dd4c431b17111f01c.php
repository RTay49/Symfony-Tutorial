<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_7165d0d2905efdf68780ffd28cee23ced77df9611aba16ba1f4e40691ca4f761 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5a391c7cf141d7dcf206fed622ac05ffa4b93bac9808111971a17f60f9689cd3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a391c7cf141d7dcf206fed622ac05ffa4b93bac9808111971a17f60f9689cd3->enter($__internal_5a391c7cf141d7dcf206fed622ac05ffa4b93bac9808111971a17f60f9689cd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_5a391c7cf141d7dcf206fed622ac05ffa4b93bac9808111971a17f60f9689cd3->leave($__internal_5a391c7cf141d7dcf206fed622ac05ffa4b93bac9808111971a17f60f9689cd3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
    }
}
