<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_d9079fbd015545aeca19603731e1753798f86be4d6ba6e4ae566fb2171d8d09a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d22c6c8314e27f139a92766c195b1fb0d5e8358172fb03428caaba4f2045326b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d22c6c8314e27f139a92766c195b1fb0d5e8358172fb03428caaba4f2045326b->enter($__internal_d22c6c8314e27f139a92766c195b1fb0d5e8358172fb03428caaba4f2045326b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_d22c6c8314e27f139a92766c195b1fb0d5e8358172fb03428caaba4f2045326b->leave($__internal_d22c6c8314e27f139a92766c195b1fb0d5e8358172fb03428caaba4f2045326b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
    }
}
