<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_81721fa114f7002711b23bb81be625e92c1e850807b00938ee6d1e205591966c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee05e391700b812e805cba210b5577c34f0f9ed87075e14fb1c0c106f77d28b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee05e391700b812e805cba210b5577c34f0f9ed87075e14fb1c0c106f77d28b4->enter($__internal_ee05e391700b812e805cba210b5577c34f0f9ed87075e14fb1c0c106f77d28b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_ee05e391700b812e805cba210b5577c34f0f9ed87075e14fb1c0c106f77d28b4->leave($__internal_ee05e391700b812e805cba210b5577c34f0f9ed87075e14fb1c0c106f77d28b4_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_fb555839a201d74617801e5a55c958154981f94c9070105b42e6e29ce93d79b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb555839a201d74617801e5a55c958154981f94c9070105b42e6e29ce93d79b3->enter($__internal_fb555839a201d74617801e5a55c958154981f94c9070105b42e6e29ce93d79b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_fb555839a201d74617801e5a55c958154981f94c9070105b42e6e29ce93d79b3->leave($__internal_fb555839a201d74617801e5a55c958154981f94c9070105b42e6e29ce93d79b3_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSource()
    {
        return "{% block panel '' %}
";
    }
}
