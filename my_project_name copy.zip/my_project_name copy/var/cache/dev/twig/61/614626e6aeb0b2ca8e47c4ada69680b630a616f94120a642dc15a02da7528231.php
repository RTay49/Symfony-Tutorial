<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_30d4f1c845dd50f5173aaf98d7089558b0ec6e6edceea3924a9f3e52a3e7aa12 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb234ad6a7351bbd4c25833181b13f1006e5893f85aecb6b6716fe4373da407e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb234ad6a7351bbd4c25833181b13f1006e5893f85aecb6b6716fe4373da407e->enter($__internal_fb234ad6a7351bbd4c25833181b13f1006e5893f85aecb6b6716fe4373da407e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_fb234ad6a7351bbd4c25833181b13f1006e5893f85aecb6b6716fe4373da407e->leave($__internal_fb234ad6a7351bbd4c25833181b13f1006e5893f85aecb6b6716fe4373da407e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
    }
}
