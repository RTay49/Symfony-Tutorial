<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_c458d78e94c99c20deb267a97330be122780abacfc381c89741f71f98ecb0e15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_054b41614d1eff713097c1d3f87a6c2a228c02828e77a9f0beb4876826656605 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_054b41614d1eff713097c1d3f87a6c2a228c02828e77a9f0beb4876826656605->enter($__internal_054b41614d1eff713097c1d3f87a6c2a228c02828e77a9f0beb4876826656605_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_054b41614d1eff713097c1d3f87a6c2a228c02828e77a9f0beb4876826656605->leave($__internal_054b41614d1eff713097c1d3f87a6c2a228c02828e77a9f0beb4876826656605_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
    }
}
