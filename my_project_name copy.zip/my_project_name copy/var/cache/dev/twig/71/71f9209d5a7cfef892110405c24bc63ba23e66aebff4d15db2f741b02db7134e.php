<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_3bb8f852bbd78191bebe1c2012ebf9e2f2f4d5f8f7dc8324b13d9d7ff9cf7c59 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec68467c33cb9d4d02c9b366843086d9cbff4a59de8febebd5b102bea7cf741b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec68467c33cb9d4d02c9b366843086d9cbff4a59de8febebd5b102bea7cf741b->enter($__internal_ec68467c33cb9d4d02c9b366843086d9cbff4a59de8febebd5b102bea7cf741b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_ec68467c33cb9d4d02c9b366843086d9cbff4a59de8febebd5b102bea7cf741b->leave($__internal_ec68467c33cb9d4d02c9b366843086d9cbff4a59de8febebd5b102bea7cf741b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
    }
}
