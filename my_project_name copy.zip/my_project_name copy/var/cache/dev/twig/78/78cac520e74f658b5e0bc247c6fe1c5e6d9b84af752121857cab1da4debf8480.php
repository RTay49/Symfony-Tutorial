<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_103c205b6eb247ed2656cfe758bda737acd394375f25fb88e83b4d5664841cb6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_34516b0fddf569ed3e14137bc9c87fb9e07f64efc2f4f00366b7098e3a89dfee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34516b0fddf569ed3e14137bc9c87fb9e07f64efc2f4f00366b7098e3a89dfee->enter($__internal_34516b0fddf569ed3e14137bc9c87fb9e07f64efc2f4f00366b7098e3a89dfee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_34516b0fddf569ed3e14137bc9c87fb9e07f64efc2f4f00366b7098e3a89dfee->leave($__internal_34516b0fddf569ed3e14137bc9c87fb9e07f64efc2f4f00366b7098e3a89dfee_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
    }
}
