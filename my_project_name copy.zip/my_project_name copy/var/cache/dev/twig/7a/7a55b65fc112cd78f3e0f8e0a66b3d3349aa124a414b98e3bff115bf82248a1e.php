<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_25aefc5c03266e145e430f0531fff67221f7fd47a64b33d851f1bd610b420a4e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b049afff11810fe3df637df4024e2c60726ae8db07f6c1aadee49f04386e01e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b049afff11810fe3df637df4024e2c60726ae8db07f6c1aadee49f04386e01e2->enter($__internal_b049afff11810fe3df637df4024e2c60726ae8db07f6c1aadee49f04386e01e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_b049afff11810fe3df637df4024e2c60726ae8db07f6c1aadee49f04386e01e2->leave($__internal_b049afff11810fe3df637df4024e2c60726ae8db07f6c1aadee49f04386e01e2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
    }
}
