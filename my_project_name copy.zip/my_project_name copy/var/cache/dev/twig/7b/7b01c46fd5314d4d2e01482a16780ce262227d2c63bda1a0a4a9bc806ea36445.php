<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_cee190a6cedcafdace858ed5738af66a015c222ec4328bda833678e0532644b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c258f54ce397fb071baa1bce3ff58840bba78ba7bea456766e7805098cc70f09 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c258f54ce397fb071baa1bce3ff58840bba78ba7bea456766e7805098cc70f09->enter($__internal_c258f54ce397fb071baa1bce3ff58840bba78ba7bea456766e7805098cc70f09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_c258f54ce397fb071baa1bce3ff58840bba78ba7bea456766e7805098cc70f09->leave($__internal_c258f54ce397fb071baa1bce3ff58840bba78ba7bea456766e7805098cc70f09_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
    }
}
