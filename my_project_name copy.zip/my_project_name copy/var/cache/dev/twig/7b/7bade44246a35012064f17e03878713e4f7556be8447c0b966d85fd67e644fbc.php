<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_7a63a6467aedb39ba1c74199ab0f7b3be9a7969298bfe45b73373444d020f09a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66593ee9b550ad2f05d75c3ef8e9f244efc86eaf5766cf0d30859e277905163f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66593ee9b550ad2f05d75c3ef8e9f244efc86eaf5766cf0d30859e277905163f->enter($__internal_66593ee9b550ad2f05d75c3ef8e9f244efc86eaf5766cf0d30859e277905163f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_66593ee9b550ad2f05d75c3ef8e9f244efc86eaf5766cf0d30859e277905163f->leave($__internal_66593ee9b550ad2f05d75c3ef8e9f244efc86eaf5766cf0d30859e277905163f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->widget(\$form) ?>
";
    }
}
