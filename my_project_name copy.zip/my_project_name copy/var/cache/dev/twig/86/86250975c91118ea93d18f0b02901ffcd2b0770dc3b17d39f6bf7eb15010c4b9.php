<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_ac2f046baccbbf14a1075e69c8d12d222682bdb224eeb519b8f208098b38d5be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f3489bfa6eb326437426b27c38617a4c8e95ab78691a28d60e968bbb6eea96ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3489bfa6eb326437426b27c38617a4c8e95ab78691a28d60e968bbb6eea96ad->enter($__internal_f3489bfa6eb326437426b27c38617a4c8e95ab78691a28d60e968bbb6eea96ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_f3489bfa6eb326437426b27c38617a4c8e95ab78691a28d60e968bbb6eea96ad->leave($__internal_f3489bfa6eb326437426b27c38617a4c8e95ab78691a28d60e968bbb6eea96ad_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
    }
}
