<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_5f017ef817335f959d0ca7b714a44216d82a4e65f39853a1c87b42712e4a7ad6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1c7e3977b41b3d9b1a9927071ee74faf12ec6ac0d0bbabcc3a669c30ac46021 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1c7e3977b41b3d9b1a9927071ee74faf12ec6ac0d0bbabcc3a669c30ac46021->enter($__internal_f1c7e3977b41b3d9b1a9927071ee74faf12ec6ac0d0bbabcc3a669c30ac46021_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_f1c7e3977b41b3d9b1a9927071ee74faf12ec6ac0d0bbabcc3a669c30ac46021->leave($__internal_f1c7e3977b41b3d9b1a9927071ee74faf12ec6ac0d0bbabcc3a669c30ac46021_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
    }
}
