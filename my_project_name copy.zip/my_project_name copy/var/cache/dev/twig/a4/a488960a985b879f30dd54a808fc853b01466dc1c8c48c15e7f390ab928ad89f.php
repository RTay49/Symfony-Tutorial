<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_75a3dcf1874d224f1f359096b8702a3f461b761ec2f496c857c68c7eb72e0b41 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1bd215d59cbfc3baba15d391af40a02e7ecb86090b1032453b125cde36f558a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bd215d59cbfc3baba15d391af40a02e7ecb86090b1032453b125cde36f558a4->enter($__internal_1bd215d59cbfc3baba15d391af40a02e7ecb86090b1032453b125cde36f558a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_1bd215d59cbfc3baba15d391af40a02e7ecb86090b1032453b125cde36f558a4->leave($__internal_1bd215d59cbfc3baba15d391af40a02e7ecb86090b1032453b125cde36f558a4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
    }
}
