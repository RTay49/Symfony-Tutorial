<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_582edd69b30d75d6135ab61300c143c47cd6b45aacf075a2bec48fd17527f1f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_37c9403d3725bb5b72e0a8e0d66c3d6f3ebcd2c8c6a3cf66f47522872e09d6f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37c9403d3725bb5b72e0a8e0d66c3d6f3ebcd2c8c6a3cf66f47522872e09d6f9->enter($__internal_37c9403d3725bb5b72e0a8e0d66c3d6f3ebcd2c8c6a3cf66f47522872e09d6f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_37c9403d3725bb5b72e0a8e0d66c3d6f3ebcd2c8c6a3cf66f47522872e09d6f9->leave($__internal_37c9403d3725bb5b72e0a8e0d66c3d6f3ebcd2c8c6a3cf66f47522872e09d6f9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
    }
}
