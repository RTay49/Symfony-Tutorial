<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_6b2b33aa069e3c2531fffde64b3ad183773585ca0115bccdd63e3d19b4ccfe21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a2ea35ec43536cdd953152235077362d0f642398511964445b12b3493c13b5b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a2ea35ec43536cdd953152235077362d0f642398511964445b12b3493c13b5b->enter($__internal_1a2ea35ec43536cdd953152235077362d0f642398511964445b12b3493c13b5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_1a2ea35ec43536cdd953152235077362d0f642398511964445b12b3493c13b5b->leave($__internal_1a2ea35ec43536cdd953152235077362d0f642398511964445b12b3493c13b5b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/error.xml.twig' %}
";
    }
}
