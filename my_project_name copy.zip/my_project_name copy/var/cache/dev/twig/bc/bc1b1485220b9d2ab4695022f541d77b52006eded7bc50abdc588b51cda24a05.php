<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_1f8a6cf9326c4af8c70f5cddb91869bcaa1d885e5b4716d0af7e5d8c445d5f30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bce8acb625eb2e10a294911ff9dc2ec22d4ecaef6bf33a8c41826cabadd7b834 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bce8acb625eb2e10a294911ff9dc2ec22d4ecaef6bf33a8c41826cabadd7b834->enter($__internal_bce8acb625eb2e10a294911ff9dc2ec22d4ecaef6bf33a8c41826cabadd7b834_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_bce8acb625eb2e10a294911ff9dc2ec22d4ecaef6bf33a8c41826cabadd7b834->leave($__internal_bce8acb625eb2e10a294911ff9dc2ec22d4ecaef6bf33a8c41826cabadd7b834_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
    }
}
