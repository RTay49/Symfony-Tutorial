<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_e2cc989c9745cc3844dd77892c78390e2a76e6157976a3be4a63362d71483643 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0aaf611ae5635b07a30924f30fa29bdfd03f091736c06ab3c2fd304fec3c4dd5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0aaf611ae5635b07a30924f30fa29bdfd03f091736c06ab3c2fd304fec3c4dd5->enter($__internal_0aaf611ae5635b07a30924f30fa29bdfd03f091736c06ab3c2fd304fec3c4dd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_0aaf611ae5635b07a30924f30fa29bdfd03f091736c06ab3c2fd304fec3c4dd5->leave($__internal_0aaf611ae5635b07a30924f30fa29bdfd03f091736c06ab3c2fd304fec3c4dd5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSource()
    {
        return "";
    }
}
