<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_13a5f7a09467b1341ab85969d6081e13da309f80923582ecac2d11192b483615 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8971c0493cf75443efad22ffef8bc76be5d7d625aec97fc5987916e3e89f59f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8971c0493cf75443efad22ffef8bc76be5d7d625aec97fc5987916e3e89f59f->enter($__internal_f8971c0493cf75443efad22ffef8bc76be5d7d625aec97fc5987916e3e89f59f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_f8971c0493cf75443efad22ffef8bc76be5d7d625aec97fc5987916e3e89f59f->leave($__internal_f8971c0493cf75443efad22ffef8bc76be5d7d625aec97fc5987916e3e89f59f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
    }
}
