<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_b120845aba9f41e76310587ec618b49020f48128190ce1a97aeb303a93841ef5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0e7fd4d76dad2c9905d90dae139f07e9dbc05120d7bcbc2b38887623a76922f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e7fd4d76dad2c9905d90dae139f07e9dbc05120d7bcbc2b38887623a76922f2->enter($__internal_0e7fd4d76dad2c9905d90dae139f07e9dbc05120d7bcbc2b38887623a76922f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0e7fd4d76dad2c9905d90dae139f07e9dbc05120d7bcbc2b38887623a76922f2->leave($__internal_0e7fd4d76dad2c9905d90dae139f07e9dbc05120d7bcbc2b38887623a76922f2_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_bf62c9a7126804e840c79d68e160a6470a5d0494c14a2b2103bf303dbd3c1234 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf62c9a7126804e840c79d68e160a6470a5d0494c14a2b2103bf303dbd3c1234->enter($__internal_bf62c9a7126804e840c79d68e160a6470a5d0494c14a2b2103bf303dbd3c1234_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_bf62c9a7126804e840c79d68e160a6470a5d0494c14a2b2103bf303dbd3c1234->leave($__internal_bf62c9a7126804e840c79d68e160a6470a5d0494c14a2b2103bf303dbd3c1234_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a656b41765e2d3e932f3ebfbbc03b0e7194c3c5ac375b306c27f9d3eebf53059 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a656b41765e2d3e932f3ebfbbc03b0e7194c3c5ac375b306c27f9d3eebf53059->enter($__internal_a656b41765e2d3e932f3ebfbbc03b0e7194c3c5ac375b306c27f9d3eebf53059_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a656b41765e2d3e932f3ebfbbc03b0e7194c3c5ac375b306c27f9d3eebf53059->leave($__internal_a656b41765e2d3e932f3ebfbbc03b0e7194c3c5ac375b306c27f9d3eebf53059_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_aeb8b380735f7049fa838c06f4b139429340f4539ba85f80d799aa1c7fdf4e1d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aeb8b380735f7049fa838c06f4b139429340f4539ba85f80d799aa1c7fdf4e1d->enter($__internal_aeb8b380735f7049fa838c06f4b139429340f4539ba85f80d799aa1c7fdf4e1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_aeb8b380735f7049fa838c06f4b139429340f4539ba85f80d799aa1c7fdf4e1d->leave($__internal_aeb8b380735f7049fa838c06f4b139429340f4539ba85f80d799aa1c7fdf4e1d_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
