<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_f8e98c38392bd67b9a298ce1bd19f7ac5c2d2db3df608b03c1b4860a393a4aea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f3f64931e76e1d16edd6e848c411ae3e942cbfc537c9e611301d2a061969e1c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3f64931e76e1d16edd6e848c411ae3e942cbfc537c9e611301d2a061969e1c0->enter($__internal_f3f64931e76e1d16edd6e848c411ae3e942cbfc537c9e611301d2a061969e1c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_f3f64931e76e1d16edd6e848c411ae3e942cbfc537c9e611301d2a061969e1c0->leave($__internal_f3f64931e76e1d16edd6e848c411ae3e942cbfc537c9e611301d2a061969e1c0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
    }
}
