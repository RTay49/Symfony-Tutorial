<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_ca80228a1a7e0bc9f6ce1211ce974d8f7177141d5427ba0f78f65affacbc7ff8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b84adc37c17422c9dae11314d74f5767d64591b8220fa151e4cdc087923d12d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b84adc37c17422c9dae11314d74f5767d64591b8220fa151e4cdc087923d12d7->enter($__internal_b84adc37c17422c9dae11314d74f5767d64591b8220fa151e4cdc087923d12d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_b84adc37c17422c9dae11314d74f5767d64591b8220fa151e4cdc087923d12d7->leave($__internal_b84adc37c17422c9dae11314d74f5767d64591b8220fa151e4cdc087923d12d7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
    }
}
