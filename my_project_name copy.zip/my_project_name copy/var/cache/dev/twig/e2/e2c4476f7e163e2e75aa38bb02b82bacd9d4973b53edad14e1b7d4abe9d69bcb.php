<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_5493b03a38a9ec7f6e968b1a6c4f1c8f55ccfd7226d9d1d6ecddbc122c5618a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c029b3fc6836e35125a3fcc5216b32c7f1c6a21cd40f54e949b80460b8606d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c029b3fc6836e35125a3fcc5216b32c7f1c6a21cd40f54e949b80460b8606d2->enter($__internal_6c029b3fc6836e35125a3fcc5216b32c7f1c6a21cd40f54e949b80460b8606d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_6c029b3fc6836e35125a3fcc5216b32c7f1c6a21cd40f54e949b80460b8606d2->leave($__internal_6c029b3fc6836e35125a3fcc5216b32c7f1c6a21cd40f54e949b80460b8606d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
    }
}
