<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_dd372bd801e5ca8aab27ac7049f87758cce4e002faf5452668263347a187de07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1480f5857157904a15da482bfce709e8ae2ea6a41f3a032ba1bd8b7f1d6963dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1480f5857157904a15da482bfce709e8ae2ea6a41f3a032ba1bd8b7f1d6963dd->enter($__internal_1480f5857157904a15da482bfce709e8ae2ea6a41f3a032ba1bd8b7f1d6963dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_1480f5857157904a15da482bfce709e8ae2ea6a41f3a032ba1bd8b7f1d6963dd->leave($__internal_1480f5857157904a15da482bfce709e8ae2ea6a41f3a032ba1bd8b7f1d6963dd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
    }
}
