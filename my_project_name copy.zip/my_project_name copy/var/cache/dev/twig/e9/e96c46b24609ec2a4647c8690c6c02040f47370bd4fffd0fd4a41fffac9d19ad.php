<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_7623ba582685aecbd6cdb5126454e04ea472bb1b88a4b48faff3af94e1b66d0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b064db24e823dcee4b610f28634d718f274279b49a5fa69004b18f205d83ba99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b064db24e823dcee4b610f28634d718f274279b49a5fa69004b18f205d83ba99->enter($__internal_b064db24e823dcee4b610f28634d718f274279b49a5fa69004b18f205d83ba99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_b064db24e823dcee4b610f28634d718f274279b49a5fa69004b18f205d83ba99->leave($__internal_b064db24e823dcee4b610f28634d718f274279b49a5fa69004b18f205d83ba99_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
    }
}
