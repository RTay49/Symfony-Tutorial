<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_02db4c195ba25ce7b4b714eb5eac3152f1a25aa9f20ba5d9c981b58307fdcafd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66bb67b737cdfc2953e2a50cdaefa17a5baffb5f57d3e0fa1b99532d2c1b2910 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66bb67b737cdfc2953e2a50cdaefa17a5baffb5f57d3e0fa1b99532d2c1b2910->enter($__internal_66bb67b737cdfc2953e2a50cdaefa17a5baffb5f57d3e0fa1b99532d2c1b2910_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_66bb67b737cdfc2953e2a50cdaefa17a5baffb5f57d3e0fa1b99532d2c1b2910->leave($__internal_66bb67b737cdfc2953e2a50cdaefa17a5baffb5f57d3e0fa1b99532d2c1b2910_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
    }
}
