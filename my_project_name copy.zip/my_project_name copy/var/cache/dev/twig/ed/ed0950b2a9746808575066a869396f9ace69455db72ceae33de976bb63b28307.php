<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_4bc20eee4d1e3e6cf256b639b276576ba3fd76f5c65a5e9a4c5ee44fef987029 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93e62be4967ea10c2c213ad0a0fb979695165a392476b6c2e4b263da04bc5530 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93e62be4967ea10c2c213ad0a0fb979695165a392476b6c2e4b263da04bc5530->enter($__internal_93e62be4967ea10c2c213ad0a0fb979695165a392476b6c2e4b263da04bc5530_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_93e62be4967ea10c2c213ad0a0fb979695165a392476b6c2e4b263da04bc5530->leave($__internal_93e62be4967ea10c2c213ad0a0fb979695165a392476b6c2e4b263da04bc5530_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
    }
}
