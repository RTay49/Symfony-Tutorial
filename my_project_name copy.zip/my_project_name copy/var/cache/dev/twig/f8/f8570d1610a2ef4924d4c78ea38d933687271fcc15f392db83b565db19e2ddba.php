<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_e48118a1732f1e1317640260ed657c49ef1c3be3f81058454fc53a215c03f16e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc7402b32fb076ed27eea0647100f6fc801f9c89ba656d4fdef80161b60516c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc7402b32fb076ed27eea0647100f6fc801f9c89ba656d4fdef80161b60516c0->enter($__internal_bc7402b32fb076ed27eea0647100f6fc801f9c89ba656d4fdef80161b60516c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_bc7402b32fb076ed27eea0647100f6fc801f9c89ba656d4fdef80161b60516c0->leave($__internal_bc7402b32fb076ed27eea0647100f6fc801f9c89ba656d4fdef80161b60516c0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
    }
}
