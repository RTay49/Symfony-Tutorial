<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_37d0e118f0f51afee910ca4539eb0ebbb6c7c860634a17309e6c807b121e5e32 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_74e9525a34093fba8410c9ae24048068e44c8d13adfe3ab8dc63fb61be86785f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74e9525a34093fba8410c9ae24048068e44c8d13adfe3ab8dc63fb61be86785f->enter($__internal_74e9525a34093fba8410c9ae24048068e44c8d13adfe3ab8dc63fb61be86785f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_74e9525a34093fba8410c9ae24048068e44c8d13adfe3ab8dc63fb61be86785f->leave($__internal_74e9525a34093fba8410c9ae24048068e44c8d13adfe3ab8dc63fb61be86785f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
    }
}
